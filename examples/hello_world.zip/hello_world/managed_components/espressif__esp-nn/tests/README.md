# Tests for esp_nn library

- Include these in your test framework and run the framework.
- For IDF test please refer `test_app`
